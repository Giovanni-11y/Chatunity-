#!bin/bash
GREEN='\033[0;32m'
while : 
do
echo "${GREEN} connettendo.."
    node index.js
    sleep 1

done
