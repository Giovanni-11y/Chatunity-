//creazione di riad il padre santo
function _0x331e() {
    const _0x453707 = [
        'error',
        'WZqhU',
        'isGroup',
        'pollCreationMessage',
        'IcHgf',
        'pollCreationMessageV2',
        'keys',
        'EWCvX',
        '9389VuQxYG',
        'uRJRv',
        'isBaileys',
        'key',
        '>\x20⚠\x20𝐒𝐎𝐍𝐃𝐀𝐆𝐆𝐈𝐎\x20𝐑𝐈𝐋𝐄𝐕𝐀𝐓𝐎\x20⚠\x0a𝐈𝐥\x20𝐬𝐨𝐧𝐝𝐚𝐠𝐠𝐢𝐨\x20𝐝𝐢\x20@',
        'sendMessage',
        'sender',
        '16RJEKjK',
        '523424GcGEYy',
        '691875gkGbfv',
        '631372wOIKtL',
        'chat',
        'chats',
        'split',
        'message',
        'participant',
        '316305IDgTaQ',
        'antisondaggi',
        'YUOoi',
        'WJxhX',
        'data',
        '\x20𝐞̀\x20𝐬𝐭𝐚𝐭𝐨\x20𝐞𝐥𝐢𝐦𝐢𝐧𝐚𝐭𝐨.',
        'YzGjg',
        '451340TuqKQu',
        '14hzAQbN',
        '5ElGgwZ',
        '644262rTWEfP'
    ];
    _0x331e = function () {
        return _0x453707;
    };
    return _0x331e();
}
(function (_0x18f45d, _0x51aba5) {
    const _0x4f3607 = _0x1d58, _0xaea9c1 = _0x18f45d();
    while (!![]) {
        try {
            const _0x1c40f2 = -parseInt(_0x4f3607(0x81)) / (-0x146e + -0x425 + 0x23c * 0xb) * (-parseInt(_0x4f3607(0x76)) / (0x2397 + -0x755 * 0x5 + 0x114)) + parseInt(_0x4f3607(0x6e)) / (-0x1de7 + 0xc1b * 0x2 + 0x5b4) + -parseInt(_0x4f3607(0x89)) / (0xeb + -0xb58 + -0xf3 * -0xb) + parseInt(_0x4f3607(0x77)) / (0x1 * 0x1c55 + 0xafc + 0x5 * -0x7dc) * (-parseInt(_0x4f3607(0x78)) / (0xff1 + -0x6b9 + 0xb * -0xd6)) + -parseInt(_0x4f3607(0x8b)) / (0xeed * -0x1 + -0xa65 + 0x1959 * 0x1) * (-parseInt(_0x4f3607(0x88)) / (0x1f2c + 0x207d * -0x1 + 0x159)) + parseInt(_0x4f3607(0x8a)) / (0x2434 + 0xa * 0xd1 + -0x2c55) + -parseInt(_0x4f3607(0x75)) / (-0x629 + 0x1e55 + -0x1822);
            if (_0x1c40f2 === _0x51aba5)
                break;
            else
                _0xaea9c1['push'](_0xaea9c1['shift']());
        } catch (_0x30de73) {
            _0xaea9c1['push'](_0xaea9c1['shift']());
        }
    }
}(_0x331e, -0x344fc + -0x2f7e5 + 0x87383));
function _0x1d58(_0x1e7ba8, _0x345f05) {
    const _0x3fc3af = _0x331e();
    return _0x1d58 = function (_0x5806ba, _0x4e4b9a) {
        _0x5806ba = _0x5806ba - (0x1a1 + 0xc48 + -0xd7f * 0x1);
        let _0xa94d77 = _0x3fc3af[_0x5806ba];
        return _0xa94d77;
    }, _0x1d58(_0x1e7ba8, _0x345f05);
}
export async function before(_0x16c1fd, {
    isAdmin: _0x477ddb,
    isBotAdmin: _0x2b30b1,
    conn: _0x5de788
}) {
    const _0x487a6e = _0x1d58, _0x50c579 = {
            'WJxhX': function (_0x1e0f32, _0x3ad915) {
                return _0x1e0f32 === _0x3ad915;
            },
            'uRJRv': _0x487a6e(0x7c),
            'fJyth': function (_0x1bc8c2, _0x385830) {
                return _0x1bc8c2 === _0x385830;
            },
            'EWCvX': _0x487a6e(0x7e),
            'YUOoi': function (_0x41804a, _0x44f445) {
                return _0x41804a === _0x44f445;
            },
            'WZqhU': 'pollCreationMessageV3',
            'YzGjg': function (_0x4e9de2, _0x45f2d3) {
                return _0x4e9de2 && _0x45f2d3;
            },
            'IcHgf': 'Errore:'
        };
    if (!_0x16c1fd[_0x487a6e(0x7b)] || _0x16c1fd[_0x487a6e(0x83)])
        return !![];
    // Check if antisondaggi is enabled for this chat
    let _0x1e4353 = global['db'][_0x487a6e(0x72)][_0x487a6e(0x6a)][_0x16c1fd[_0x487a6e(0x8c)]];
    if (!_0x1e4353['antisondaggi'])
        return !![];
    const _0x278b50 = Object[_0x487a6e(0x7f)](_0x16c1fd[_0x487a6e(0x6c)] || {})[-0xcd9 * 0x1 + 0x25b5 * -0x1 + 0x328e], _0x13e24e = _0x50c579[_0x487a6e(0x71)](_0x278b50, _0x50c579[_0x487a6e(0x82)]) || _0x50c579['fJyth'](_0x278b50, _0x50c579[_0x487a6e(0x80)]) || _0x50c579[_0x487a6e(0x70)](_0x278b50, _0x50c579[_0x487a6e(0x7a)]);
    if (_0x50c579[_0x487a6e(0x74)](_0x13e24e, !_0x477ddb))
        try {
            await _0x5de788[_0x487a6e(0x86)](_0x16c1fd[_0x487a6e(0x8c)], {
                'delete': {
                    'remoteJid': _0x16c1fd[_0x487a6e(0x8c)],
                    'fromMe': ![],
                    'id': _0x16c1fd[_0x487a6e(0x84)]['id'],
                    'participant': _0x16c1fd[_0x487a6e(0x84)][_0x487a6e(0x6d)] || _0x16c1fd[_0x487a6e(0x87)]
                }
            }), await _0x5de788['sendMessage'](_0x16c1fd[_0x487a6e(0x8c)], {
                'text': _0x487a6e(0x85) + _0x16c1fd[_0x487a6e(0x87)][_0x487a6e(0x6b)]('@')[0xa0d * 0x1 + 0x1fee + -0x29fb] + _0x487a6e(0x73),
                'mentions': [_0x16c1fd[_0x487a6e(0x87)]]
            });
        } catch (_0x2d3df8) {
            console[_0x487a6e(0x79)](_0x50c579[_0x487a6e(0x7d)], _0x2d3df8);
        }
    return !![];
}