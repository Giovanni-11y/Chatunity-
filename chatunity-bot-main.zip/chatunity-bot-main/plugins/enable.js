const _0x1fa325 = _0x46b8;
function _0x46b8(_0x56a7, _0x496ad9) {
    const _0x1f60d4 = _0x2086();
    return _0x46b8 = function (_0xef7a9, _0x5ef828) {
        _0xef7a9 = _0xef7a9 - (-0x1367 + -0x1af * -0x3 + 0x1023);
        let _0x4b612f = _0x1f60d4[_0xef7a9];
        return _0x4b612f;
    }, _0x46b8(_0x56a7, _0x496ad9);
}
(function (_0x48a9b6, _0x4402bd) {
    const _0x522586 = _0x46b8, _0x5f23e5 = _0x48a9b6();
    while (!![]) {
        try {
            const _0x599247 = parseInt(_0x522586(0x221)) / (0x1 * 0x176d + -0x1c41 + 0x4d5) * (-parseInt(_0x522586(0x254)) / (0xee + 0x2407 + 0x24f3 * -0x1)) + parseInt(_0x522586(0x1fd)) / (-0x595 * 0x4 + 0x2164 + 0x45 * -0x29) * (-parseInt(_0x522586(0x240)) / (0xc0f + 0x87e * -0x1 + -0x38d)) + parseInt(_0x522586(0x1d1)) / (-0xdfc + -0x7cd * 0x3 + 0x7 * 0x558) * (-parseInt(_0x522586(0x20e)) / (0x19bf + -0x1bb4 + -0x27 * -0xd)) + parseInt(_0x522586(0x20a)) / (0x138e + 0x1b * -0x149 + 0xf2c) + parseInt(_0x522586(0x244)) / (-0x5c1 * -0x1 + -0x13ae + 0xdf5) * (parseInt(_0x522586(0x1fb)) / (-0x1e43 * -0x1 + -0x3e2 + -0x1a58)) + -parseInt(_0x522586(0x218)) / (0xa25 + -0x6a2 * 0x1 + 0x7 * -0x7f) * (parseInt(_0x522586(0x24f)) / (-0x195 * -0xb + 0x30 * 0x38 + -0xdee * 0x2)) + -parseInt(_0x522586(0x219)) / (0xcd2 + -0x16bc + 0xff * 0xa) * (-parseInt(_0x522586(0x24c)) / (0x9 * -0x1b6 + -0x10 * -0x11 + -0x7f * -0x1d));
            if (_0x599247 === _0x4402bd)
                break;
            else
                _0x5f23e5['push'](_0x5f23e5['shift']());
        } catch (_0x34a2a8) {
            _0x5f23e5['push'](_0x5f23e5['shift']());
        }
    }
}(_0x2086, -0x1 * -0x1d319 + 0x109d5 + 0x74c6b));
function _0x2086() {
    const _0x2fa95c = [
        'hzleJ',
        'XYHuA',
        'BcCKh',
        'isGroup',
        'dpDgl',
        '┃◈┃',
        '296204EFDlZs',
        '🔧\x20Funzioni',
        'risposte',
        'toLowerCase',
        '8AmFcok',
        'djLvO',
        'chats',
        '\x0a┃◈┃\x0a┃◈└───────────┈⊷\x0a┃◈┃•\x20*𝑽𝑬𝑹𝑺𝑰𝑶𝑵𝑬:*\x20',
        'Antibot',
        'Attiva/Disattiva\x20',
        'map',
        'gaMZg',
        '35018139ZImehH',
        'Antilink',
        '⚙\x20Impostazioni\x20',
        '55UiXbDr',
        'sendMessage',
        'SoloPrivato',
        'undefined',
        'https://telegra.ph/file/00edd0958c94359540a8f.png',
        '354222vLvczL',
        'JlbkW',
        'wbEqG',
        'antiSpam',
        'chatbotPrivato',
        'FSEpo',
        'GGnlF',
        'antispamcomandi',
        'Antilinkhard',
        'Antimedia',
        'antiinsta',
        'getName',
        'tags',
        '5gXewNh',
        './plugins/cornuto.js',
        'Benvenuto',
        '\x0a╰━━━━━━━━━━━━━┈·๏\x0a',
        'group',
        'BEGIN:VCARD...',
        'Questo\x20comando\x20è\x20disponibile\x20solo\x20con\x20la\x20base\x20di\x20ChatUnity.',
        'uZcFO',
        'PVeQS',
        'help',
        'AntiTikTok',
        'TtvDr',
        'antimedia',
        'msPzx',
        'CUUbf',
        'antiviewonce',
        'nVkda',
        'kXUxn',
        '📋\x20Lista\x20Comandi',
        'WaezD',
        'Impostazioni\x20Bot',
        'data',
        'Antibestemmie',
        'isBanned',
        'antibot',
        'PghWq',
        'FMnGU',
        'XwuqN',
        '\x0a╭〔\x20*🔧\x20𝑴𝑬𝑺𝑺𝑨𝑮𝑮𝑖𝑶\x20𝑺𝑻𝑨𝑻𝑶*\x20〕┈⊷\x0a┃\x20𝐅𝐮𝐧𝐳𝐢𝐨𝐧𝐞\x20*',
        'key',
        'gpt',
        'antiporno',
        'privateChatbot',
        'find',
        'AntiCall',
        '❌\x20Puoi\x20attivare/disattivare\x20la\x20funzione\x20*ChatbotPrivato*\x20solo\x20in\x20chat\x20privata.',
        '𝐚𝐭𝐭𝐢𝐯𝐚𝐭𝐚',
        'sender',
        'oVnxM',
        'FSeIv',
        'jadibot',
        'HXwlm',
        '936000KEroqX',
        'Autosticker',
        '9TmeJGh',
        'AntispamComandi',
        'EfjpW',
        'attiva\x20',
        'ziqsp',
        'antitiktok',
        'RtFgi',
        'access',
        'antiArab',
        'disabilita\x20<feature>',
        'TiFTp',
        'SoloGruppo',
        'ownerOnly',
        '1389059rbpFfq',
        'test',
        'label',
        'Detect',
        '7800324nmUkDe',
        'chat',
        'reply',
        'antivoip',
        'Antitrava',
        'Antispam',
        '\x0a┃◈┃•\x20\x20𝐂𝐎𝐋𝐋𝐀𝐁:\x20𝐎𝐍𝐄\x20𝐏𝐈𝐄𝐂𝐄\x0a┃◈┃•\x20*𝐒𝐔𝐏𝐏𝐎𝐑𝐓𝐎:*\x20(.supporto)\x0a╰━━━━━━━━━━━━━┈·๏\x0a',
        'Antisondaggi',
        'aJFnT',
        '\x20(Owner)',
        '553310iPTWaJ',
        '12kUfTSm',
        'Antivirus',
        'antiCall',
        'XRhQc',
        './CODE_OF_CONDUCT.md',
        'aMtSt',
        'admin',
        '\x0a╭〔\x20*🔧\x20𝑴𝑬𝑵𝑼\x20𝑺𝑰𝑪𝑼𝑹𝑬𝑿\x20𝑩𝑶𝑻\x20🔧\x20〕┈⊷\x0a┃◈╭─────────────·๏\x0a┃◈┃•\x20*𝐀𝐓𝐓𝐈𝐕𝐀/𝐃𝐈𝐒𝐀𝐁𝐈𝐋𝐈𝐓𝐀\x0a┃◈┃\x0a┃◈┃•\x20*ℹ\x20𝐂𝐎𝐌𝐄\x20𝐒𝐈\x20𝐔𝐒𝐀*\x0a┃◈┃•\x20🟢\x20attiva\x20[funzione]\x0a┃◈┃•\x20🔴\x20disabilita\x20[funzione]\x0a┃◈┃•\x20🔴\x20disattiva\x20[funzione]\x0a┃◈┃\x0a',
        '3UGgkEc',
        '0@s.whatsapp.net',
        'JadiBot',
        'SdyqP',
        'command',
        'BsEgE',
        '𝐝𝐢𝐬𝐚𝐭𝐭𝐢𝐯𝐚𝐭𝐚',
        'leijO',
        'Antiporno',
        'antitrava',
        'antibestemmie',
        'hvYha',
        'welcome',
        'GPT',
        'sologruppo',
        'BKjeh',
        'soloadmin',
        'Antiarab',
        'autosticker',
        'Antiviewonce',
        'trim',
        'aJwFa',
        'https://telegra.ph/file/de558c2aa7fc80d32b8c3.png',
        'antisondaggi',
        'antiLink'
    ];
    _0x2086 = function () {
        return _0x2fa95c;
    };
    return _0x2086();
}
import _0x4353d7 from 'fs';
import _0x2cfcc0 from 'node-fetch';
const features = [
    {
        'key': _0x1fa325(0x239),
        'label': _0x1fa325(0x24d)
    },
    {
        'key': 'antiLinkHard',
        'label': _0x1fa325(0x1cc)
    },
    {
        'key': _0x1fa325(0x257),
        'label': _0x1fa325(0x213)
    },
    {
        'key': _0x1fa325(0x22a),
        'label': _0x1fa325(0x212)
    },
    {
        'key': _0x1fa325(0x1e0),
        'label': _0x1fa325(0x234)
    },
    {
        'key': _0x1fa325(0x233),
        'label': _0x1fa325(0x1fc)
    },
    {
        'key': _0x1fa325(0x22d),
        'label': _0x1fa325(0x1d3)
    },
    {
        'key': 'detect',
        'label': _0x1fa325(0x20d)
    },
    {
        'key': _0x1fa325(0x242),
        'label': 'Risposte'
    },
    {
        'key': _0x1fa325(0x22b),
        'label': _0x1fa325(0x1e7)
    },
    {
        'key': _0x1fa325(0x1ef),
        'label': _0x1fa325(0x22e)
    },
    {
        'key': _0x1fa325(0x1f9),
        'label': _0x1fa325(0x223)
    },
    {
        'key': _0x1fa325(0x22f),
        'label': _0x1fa325(0x208)
    },
    {
        'key': 'soloprivato',
        'label': _0x1fa325(0x251)
    },
    {
        'key': _0x1fa325(0x231),
        'label': 'soloadmin'
    },
    {
        'key': _0x1fa325(0x1e8),
        'label': 'BanGruppo'
    },
    {
        'key': _0x1fa325(0x1f0),
        'label': _0x1fa325(0x229)
    },
    {
        'key': _0x1fa325(0x21b),
        'label': _0x1fa325(0x1f3)
    },
    {
        'key': _0x1fa325(0x1ce),
        'label': 'Antiinsta'
    },
    {
        'key': _0x1fa325(0x202),
        'label': _0x1fa325(0x1db)
    },
    {
        'key': _0x1fa325(0x205),
        'label': _0x1fa325(0x232)
    },
    {
        'key': 'antivirus',
        'label': _0x1fa325(0x21a)
    },
    {
        'key': _0x1fa325(0x1e9),
        'label': _0x1fa325(0x248)
    },
    {
        'key': _0x1fa325(0x211),
        'label': 'Antivoip'
    },
    {
        'key': _0x1fa325(0x1dd),
        'label': _0x1fa325(0x1cd)
    },
    {
        'key': _0x1fa325(0x238),
        'label': _0x1fa325(0x215)
    },
    {
        'key': _0x1fa325(0x1cb),
        'label': _0x1fa325(0x1fe),
        'ownerOnly': !![]
    }
];
let handler = async (_0x36ca14, {
    conn: _0x3cf210,
    usedPrefix: _0x151d17,
    command: _0x33d3ca,
    args: _0x25b8fc,
    isOwner: _0x3d599a,
    isAdmin: _0x222ac1,
    isROwner: _0x425085
}) => {
    const _0x163928 = _0x1fa325, _0x3aa3b5 = {
            'WaezD': function (_0x53d70b, _0x2f21d3) {
                return _0x53d70b === _0x2f21d3;
            },
            'SdyqP': _0x163928(0x258),
            'XYHuA': 'PNqra',
            'BKjeh': function (_0x53b599, _0x1c1fc3) {
                return _0x53b599 === _0x1c1fc3;
            },
            'hvYha': 'antivoip',
            'HXwlm': function (_0x18d042, _0x5cc170) {
                return _0x18d042 === _0x5cc170;
            },
            'leijO': _0x163928(0x1eb),
            'vDiZd': _0x163928(0x217),
            'XRhQc': _0x163928(0x1f4),
            'msPzx': function (_0x1dfd24, _0x1e5772) {
                return _0x1dfd24 === _0x1e5772;
            },
            'uZcFO': '❌\x20Solo\x20il\x20proprietario\x20può\x20attivare/disattivare\x20questa\x20funzione.',
            'djLvO': _0x163928(0x21d),
            'FSeIv': './bal.png',
            'cZuEs': _0x163928(0x1d2),
            'CUUbf': function (_0x1443b9, _0x135038) {
                return _0x1443b9 !== _0x135038;
            },
            'hzleJ': _0x163928(0x21e),
            'PghWq': _0x163928(0x1d7),
            'JlbkW': _0x163928(0x252),
            'BcCKh': function (_0x572672, _0x56fa92) {
                return _0x572672 + _0x56fa92;
            },
            'PVeQS': _0x163928(0x24e),
            'MVmIH': _0x163928(0x1e3),
            'EfjpW': _0x163928(0x241),
            'aJFnT': 'GFyuU',
            'BsEgE': _0x163928(0x222),
            'TiFTp': '3EB0C7D95F5E5E5E',
            'wbEqG': _0x163928(0x1d6),
            'aJwFa': function (_0xc84211, _0x4edde1) {
                return _0xc84211 || _0x4edde1;
            },
            'GGnlF': function (_0x2bc920, _0x18f748) {
                return _0x2bc920 === _0x18f748;
            },
            'dpDgl': _0x163928(0x1f7),
            'gaMZg': function (_0x59bfe8, _0x243f3f) {
                return _0x59bfe8 === _0x243f3f;
            },
            'tfXFW': _0x163928(0x1f5),
            'yxPvx': _0x163928(0x227),
            'nVkda': _0x163928(0x253),
            'ziqsp': _0x163928(0x237),
            'VABBx': _0x163928(0x1e5),
            'TtvDr': function (_0x5d1c6f, _0x316c96) {
                return _0x5d1c6f(_0x316c96);
            }
        }, _0xea711f = [
            './termini.jpeg',
            _0x3aa3b5[_0x163928(0x245)],
            _0x3aa3b5[_0x163928(0x1f8)],
            _0x3aa3b5['cZuEs']
        ];
    for (const _0x4499cf of _0xea711f) {
        try {
            await _0x4353d7['promises'][_0x163928(0x204)](_0x4499cf);
        } catch {
            if (_0x3aa3b5['CUUbf'](_0x163928(0x21e), _0x3aa3b5[_0x163928(0x23a)]))
                _0x234798 = _0xdf2698['db'][_0x163928(0x1e6)]['chats'][_0x39a092[_0x163928(0x20f)]]?.[_0x163928(0x211)] || ![];
            else
                return _0x36ca14['reply'](_0x3aa3b5[_0x163928(0x1ea)]);
        }
    }
    let _0x57b646 = await _0x3cf210[_0x163928(0x1cf)](_0x36ca14[_0x163928(0x20f)]), _0x14da0b = global['db']['data'][_0x163928(0x246)][_0x36ca14['chat']] || {}, _0x1818e6 = features[_0x163928(0x24a)](_0x5b922 => {
            const _0x596870 = _0x163928;
            let _0x5d6202;
            if (_0x3aa3b5[_0x596870(0x1e4)](_0x5b922[_0x596870(0x1ee)], _0x3aa3b5[_0x596870(0x224)]))
                _0x3aa3b5[_0x596870(0x23b)] === _0x3aa3b5[_0x596870(0x23b)] ? _0x5d6202 = global[_0x596870(0x1f1)][_0x36ca14[_0x596870(0x1f6)]] || ![] : _0x3dd235 = _0x4b8d18[_0xad4bdb['key']];
            else {
                if (_0x3aa3b5[_0x596870(0x230)](_0x5b922[_0x596870(0x1ee)], _0x3aa3b5[_0x596870(0x22c)]))
                    _0x5d6202 = global['db'][_0x596870(0x1e6)][_0x596870(0x246)][_0x36ca14[_0x596870(0x20f)]]?.[_0x596870(0x211)] || ![];
                else {
                    if (_0x3aa3b5[_0x596870(0x1fa)](_0x3aa3b5[_0x596870(0x228)], _0x3aa3b5['leijO']))
                        _0x5d6202 = _0x14da0b[_0x5b922[_0x596870(0x1ee)]];
                    else
                        return _0x4b612f['reply']('Questo\x20comando\x20è\x20disponibile\x20solo\x20con\x20la\x20base\x20di\x20ChatUnity.');
                }
            }
            let _0x4575ba = _0x5d6202 ? '🟢' : '🔴', _0x24f57e = _0x5b922[_0x596870(0x209)] ? _0x3aa3b5['vDiZd'] : '';
            return _0x596870(0x23f) + _0x4575ba + '\x20*' + _0x5b922['label'] + '*' + _0x24f57e;
        })['join']('\x0a');
    const _0x5625fd = (_0x163928(0x220) + _0x1818e6 + _0x163928(0x247) + (_0x3aa3b5['CUUbf'](typeof vs, _0x3aa3b5[_0x163928(0x255)]) ? vs : '') + _0x163928(0x214))[_0x163928(0x235)]();
    let _0x394388 = _0x3aa3b5[_0x163928(0x23c)](_0x3aa3b5[_0x163928(0x1d9)], _0x57b646);
    const _0x51a900 = {
        'text': _0x5625fd,
        'footer': 'Seleziona\x20una\x20funzione\x20da\x20attivare/disattivare',
        'title': _0x394388,
        'buttonText': _0x3aa3b5['MVmIH'],
        'sections': [{
                'title': _0x3aa3b5[_0x163928(0x1ff)],
                'rows': features['map'](_0x363ebe => ({
                    'title': _0x363ebe[_0x163928(0x20c)],
                    'description': _0x163928(0x249) + _0x363ebe[_0x163928(0x20c)],
                    'rowId': _0x151d17 + _0x163928(0x200) + _0x363ebe[_0x163928(0x20c)][_0x163928(0x243)]()
                }))
            }]
    };
    let _0x55ca32 = (_0x25b8fc[-0x1a5e + -0x235b * 0x1 + 0x3db9] || '')[_0x163928(0x243)](), _0x1eb1c0 = features[_0x163928(0x1f2)](_0x124321 => _0x124321[_0x163928(0x20c)][_0x163928(0x243)]() === _0x55ca32);
    if (!_0x55ca32 || !_0x1eb1c0) {
        if (_0x3aa3b5[_0x163928(0x1df)](_0x3aa3b5[_0x163928(0x216)], _0x3aa3b5[_0x163928(0x216)]))
            _0x46e694[_0x49ef82['key']] = _0x5ddfd4;
        else {
            let _0x1a6c48 = {
                'key': {
                    'participants': _0x3aa3b5['BsEgE'],
                    'fromMe': ![],
                    'id': _0x3aa3b5[_0x163928(0x207)]
                },
                'message': {
                    'locationMessage': {
                        'name': _0x163928(0x1e5),
                        'jpegThumbnail': _0x4353d7['readFileSync']('./settings.png'),
                        'vcard': _0x3aa3b5['wbEqG']
                    }
                },
                'participant': _0x3aa3b5[_0x163928(0x226)]
            };
            return await _0x3cf210[_0x163928(0x250)](_0x36ca14[_0x163928(0x20f)], _0x51a900, { 'quoted': _0x1a6c48 });
        }
    }
    if (_0x1eb1c0['ownerOnly'] && !_0x3aa3b5[_0x163928(0x236)](_0x3d599a, _0x425085))
        return _0x3cf210[_0x163928(0x210)](_0x36ca14[_0x163928(0x20f)], _0x3aa3b5[_0x163928(0x1d8)], _0x36ca14);
    let _0x27f953 = /attiva|enable|on|1|true/i[_0x163928(0x20b)](_0x33d3ca[_0x163928(0x243)]()), _0x57eadd = /disabilita|disattiva|disable|off|0|false/i[_0x163928(0x20b)](_0x33d3ca[_0x163928(0x243)]());
    if (_0x57eadd)
        _0x27f953 = ![];
    if (_0x3aa3b5[_0x163928(0x1fa)](_0x1eb1c0[_0x163928(0x1ee)], _0x3aa3b5['hvYha']))
        _0x14da0b[_0x163928(0x211)] = _0x27f953;
    else {
        if (_0x3aa3b5[_0x163928(0x1ca)](_0x1eb1c0['key'], _0x163928(0x258))) {
            if (_0x3aa3b5['CUUbf'](_0x163928(0x1ec), _0x163928(0x1e2))) {
                if (_0x36ca14[_0x163928(0x23d)]) {
                    if (_0x3aa3b5[_0x163928(0x1df)](_0x163928(0x203), _0x163928(0x1c9)))
                        return _0x3cf210[_0x163928(0x210)](_0x36ca14[_0x163928(0x20f)], _0x3aa3b5[_0x163928(0x21c)], _0x36ca14);
                    else {
                        if (_0x7a2e00[_0x163928(0x23d)])
                            return _0x19c01a[_0x163928(0x210)](_0x28286e['chat'], _0x3aa3b5['XRhQc'], _0x4959fa);
                        _0x7826[_0x163928(0x1f1)][_0x55dff9[_0x163928(0x1f6)]] = _0x4091be;
                    }
                }
                global[_0x163928(0x1f1)][_0x36ca14[_0x163928(0x1f6)]] = _0x27f953;
            } else {
                let _0x31bced;
                if (_0x3aa3b5[_0x163928(0x1de)](_0x42fbda['key'], _0x3aa3b5[_0x163928(0x224)]))
                    _0x31bced = _0x6611cf['privateChatbot'][_0x43f292[_0x163928(0x1f6)]] || ![];
                else
                    _0x5a1de0[_0x163928(0x1ee)] === _0x3aa3b5[_0x163928(0x22c)] ? _0x31bced = _0x2fd113['db'][_0x163928(0x1e6)]['chats'][_0xbe99f5['chat']]?.[_0x163928(0x211)] || ![] : _0x31bced = _0x599612[_0x26a3af['key']];
                let _0x4128aa = _0x31bced ? '🟢' : '🔴', _0x352a17 = _0x214bb6['ownerOnly'] ? '\x20(Owner)' : '';
                return _0x163928(0x23f) + _0x4128aa + '\x20*' + _0x366f4d[_0x163928(0x20c)] + '*' + _0x352a17;
            }
        } else {
            if (_0x1eb1c0[_0x163928(0x1ee)] in _0x14da0b)
                _0x14da0b[_0x1eb1c0[_0x163928(0x1ee)]] = _0x27f953;
            else {
                if (_0x3aa3b5['CUUbf']('eFMXD', _0x3aa3b5[_0x163928(0x23e)]))
                    _0x14da0b[_0x1eb1c0[_0x163928(0x1ee)]] = _0x27f953;
                else
                    return _0x141d05[_0x163928(0x210)](_0x138805[_0x163928(0x20f)], _0x3aa3b5[_0x163928(0x1d8)], _0x232c03);
            }
        }
    }
    let _0x5709f9 = _0x3aa3b5[_0x163928(0x24b)](_0x1eb1c0[_0x163928(0x1ee)], _0x3aa3b5[_0x163928(0x224)]) ? global[_0x163928(0x1f1)][_0x36ca14['sender']] ? '🟢' : '🔴' : _0x14da0b[_0x1eb1c0[_0x163928(0x1ee)]] ? '🟢' : '🔴', _0x4e30bb = _0x27f953 ? _0x3aa3b5['tfXFW'] : _0x3aa3b5['yxPvx'], _0x481cec = (_0x163928(0x1ed) + _0x1eb1c0[_0x163928(0x20c)] + '*\x20' + _0x4e30bb + _0x163928(0x1d4))[_0x163928(0x235)]();
    const _0x3c7d68 = _0x27f953 ? _0x3aa3b5[_0x163928(0x1e1)] : _0x3aa3b5[_0x163928(0x201)];
    let _0x15c33d = {
        'key': {
            'participants': _0x3aa3b5[_0x163928(0x226)],
            'fromMe': ![],
            'id': _0x3aa3b5[_0x163928(0x207)]
        },
        'message': {
            'locationMessage': {
                'name': _0x3aa3b5['VABBx'],
                'jpegThumbnail': await (await _0x3aa3b5[_0x163928(0x1dc)](_0x2cfcc0, _0x3c7d68))['buffer'](),
                'vcard': _0x3aa3b5[_0x163928(0x256)]
            }
        },
        'participant': _0x3aa3b5[_0x163928(0x226)]
    };
    await _0x3cf210[_0x163928(0x210)](_0x36ca14[_0x163928(0x20f)], _0x481cec, null, { 'quoted': _0x15c33d });
};
handler[_0x1fa325(0x1da)] = [
    'attiva\x20<feature>',
    _0x1fa325(0x206),
    'disattiva\x20<feature>'
], handler[_0x1fa325(0x1d0)] = [
    _0x1fa325(0x1d5),
    'owner'
], handler[_0x1fa325(0x225)] = /^(attiva|disabilita|disattiva|enable|disable)/i, handler['group'] = !![], handler[_0x1fa325(0x21f)] = !![];
export default handler;