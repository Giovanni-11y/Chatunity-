const _0x249066 = _0x54a4;
(function (_0x4c81d4, _0x3c6dec) {
    const _0x3bbb79 = _0x54a4, _0x66e8ee = _0x4c81d4();
    while (!![]) {
        try {
            const _0x238ab6 = -parseInt(_0x3bbb79(0x19c)) / (0x3 * 0x465 + -0x1 * 0x257c + 0x184e) * (-parseInt(_0x3bbb79(0x1d2)) / (0x67 * -0xb + 0x1 * -0x17ab + 0x1c1a)) + parseInt(_0x3bbb79(0x1bb)) / (0x1d15 + 0xf55 + 0xecd * -0x3) * (-parseInt(_0x3bbb79(0x1be)) / (0xc80 + -0x3eb * 0x1 + 0x3 * -0x2db)) + parseInt(_0x3bbb79(0x1c5)) / (-0x55 * 0x29 + -0x62 * 0x66 + 0x34ae) * (-parseInt(_0x3bbb79(0x20f)) / (-0x1f50 + -0x2060 + 0x3fb6)) + parseInt(_0x3bbb79(0x1e7)) / (-0xd17 * 0x2 + 0x1 * 0x170e + -0x3 * -0x10d) + -parseInt(_0x3bbb79(0x1a0)) / (0xd7 * 0x16 + 0x13df * -0x1 + 0x1 * 0x16d) + parseInt(_0x3bbb79(0x1da)) / (-0x1 * 0x31b + 0x47c * -0x8 + 0x38c * 0xb) * (-parseInt(_0x3bbb79(0x1d9)) / (0x2 * -0xc4b + -0x950 + 0x5a8 * 0x6)) + -parseInt(_0x3bbb79(0x1e0)) / (-0xc5f * -0x3 + 0x2f * 0x3 + -0x259f) * (parseInt(_0x3bbb79(0x1bd)) / (-0x7 * 0x10d + -0x5d9 + -0x40 * -0x35));
            if (_0x238ab6 === _0x3c6dec)
                break;
            else
                _0x66e8ee['push'](_0x66e8ee['shift']());
        } catch (_0x5bba3e) {
            _0x66e8ee['push'](_0x66e8ee['shift']());
        }
    }
}(_0x5061, -0x4e9a * -0x1 + -0xed * -0x13 + 0x21c7e));
import { googleImage } from '@bochilteam/scraper';
import { existsSync } from 'fs';
import _0x515abc from 'axios';
const paroleproibite = [
    _0x249066(0x1e6),
    _0x249066(0x1f8),
    _0x249066(0x1b3),
    _0x249066(0x1b9),
    _0x249066(0x193),
    _0x249066(0x1cd),
    _0x249066(0x1cb),
    _0x249066(0x1a5),
    _0x249066(0x1d8),
    'sparare',
    _0x249066(0x20a),
    _0x249066(0x1e4),
    'sessuale',
    _0x249066(0x202),
    _0x249066(0x20d),
    _0x249066(0x1c8),
    _0x249066(0x1e8),
    _0x249066(0x1d1),
    _0x249066(0x203),
    'orgia',
    _0x249066(0x1f4),
    _0x249066(0x1b0),
    _0x249066(0x1c1),
    _0x249066(0x206),
    _0x249066(0x1c9),
    _0x249066(0x1a7),
    _0x249066(0x1de),
    _0x249066(0x209),
    '69',
    _0x249066(0x1ec),
    'gay\x20sex',
    'lesbica',
    'incesto',
    _0x249066(0x197),
    _0x249066(0x1fa),
    'nazista',
    _0x249066(0x1c3),
    _0x249066(0x20e),
    _0x249066(0x1dc),
    _0x249066(0x1b5),
    _0x249066(0x1f7),
    _0x249066(0x190),
    _0x249066(0x1cc),
    _0x249066(0x1b8),
    _0x249066(0x19d),
    _0x249066(0x216),
    'cocaina',
    _0x249066(0x1eb),
    'pedopornografia',
    'bestialità',
    'stupri',
    _0x249066(0x217),
    _0x249066(0x1a4),
    _0x249066(0x1bc),
    _0x249066(0x194),
    _0x249066(0x1c4),
    _0x249066(0x200),
    _0x249066(0x1ed),
    'fake\x20porno',
    'modifica\x20porno',
    _0x249066(0x192),
    _0x249066(0x19a),
    'soffocare',
    _0x249066(0x1f2),
    'uccidersi',
    _0x249066(0x1fb),
    _0x249066(0x215),
    _0x249066(0x198),
    _0x249066(0x1ac),
    _0x249066(0x1d5),
    _0x249066(0x1d3),
    _0x249066(0x19f),
    'striptease'
];
function shuffle(_0x29b1d1) {
    const _0x2b1716 = _0x249066, _0xe7acf0 = {
            'kHxcV': function (_0xc9c648, _0x7c9ea3) {
                return _0xc9c648 * _0x7c9ea3;
            },
            'WmOZy': function (_0x180f73, _0x26401c) {
                return _0x180f73 + _0x26401c;
            },
            'WuRVo': function (_0x4720bb, _0x482cb0) {
                return _0x4720bb - _0x482cb0;
            },
            'PUxiS': function (_0x27170a, _0x6eb471) {
                return _0x27170a > _0x6eb471;
            },
            'TRDzz': function (_0x1f9c7c, _0x249aed) {
                return _0x1f9c7c !== _0x249aed;
            },
            'OBZdd': _0x2b1716(0x1a6),
            'YjeXt': function (_0x2fe0c6, _0x2359eb) {
                return _0x2fe0c6 * _0x2359eb;
            },
            'NxOOC': function (_0x322aab, _0x2f0fcd) {
                return _0x322aab + _0x2f0fcd;
            }
        };
    for (let _0x344341 = _0xe7acf0[_0x2b1716(0x204)](_0x29b1d1[_0x2b1716(0x1c0)], -0x10 * 0x25a + -0x1a5b + 0x3ffc); _0xe7acf0[_0x2b1716(0x1dd)](_0x344341, -0x175 * 0x2 + 0x4f * 0x25 + -0x881); _0x344341--) {
        if (_0xe7acf0[_0x2b1716(0x1c2)](_0xe7acf0[_0x2b1716(0x1bf)], _0xe7acf0[_0x2b1716(0x1bf)])) {
            const _0x4c11d9 = _0x379af8[_0x2b1716(0x210)](_0xe7acf0['kHxcV'](_0x45ef08['random'](), _0xe7acf0[_0x2b1716(0x207)](_0x44f469, -0x12a7 + 0x1e53 * 0x1 + -0xbab)));
            [_0x2b38f1[_0x1dcd33], _0xd5033f[_0x4c11d9]] = [
                _0x4bf6cc[_0x4c11d9],
                _0x5e9575[_0x40dc2b]
            ];
        } else {
            const _0x251eaa = Math['floor'](_0xe7acf0[_0x2b1716(0x1e3)](Math[_0x2b1716(0x1a1)](), _0xe7acf0['NxOOC'](_0x344341, -0x2567 + -0x128 * 0x5 + 0x2b30)));
            [_0x29b1d1[_0x344341], _0x29b1d1[_0x251eaa]] = [
                _0x29b1d1[_0x251eaa],
                _0x29b1d1[_0x344341]
            ];
        }
    }
}
function _0x54a4(_0x322334, _0x418e9a) {
    const _0x25c448 = _0x5061();
    return _0x54a4 = function (_0xbb1fe1, _0x4e25c5) {
        _0xbb1fe1 = _0xbb1fe1 - (-0xba7 * 0x1 + -0x74c + 0x1482);
        let _0x41bf0b = _0x25c448[_0xbb1fe1];
        return _0x41bf0b;
    }, _0x54a4(_0x322334, _0x418e9a);
}
const handler = async (_0x862d6c, {
    conn: _0x10a941,
    text: _0x165293,
    usedPrefix: _0x357a8d,
    command: _0x1d3431
}) => {
    const _0x315e28 = _0x249066, _0x2e02e1 = {
            'KTATl': function (_0x3f665a, _0x137d60) {
                return _0x3f665a > _0x137d60;
            },
            'dQiQO': function (_0x310048, _0x24788e) {
                return _0x310048 * _0x24788e;
            },
            'hNtTa': function (_0x1251b0, _0x31cc0e) {
                return _0x1251b0 + _0x31cc0e;
            },
            'GVNaE': 'Questo\x20comando\x20è\x20disponibile\x20solo\x20con\x20la\x20base\x20di\x20ChatUnity.',
            'jbiPA': './termini.jpeg',
            'rbypt': _0x315e28(0x195),
            'njTbd': _0x315e28(0x1d0),
            'dZVkb': function (_0x5e18c5, _0x36f0fb) {
                return _0x5e18c5 === _0x36f0fb;
            },
            'TIPdJ': _0x315e28(0x1f3),
            'pGVEf': function (_0x579aa4, _0x423ec3) {
                return _0x579aa4(_0x423ec3);
            },
            'tPLdF': _0x315e28(0x1ee),
            'QdWeZ': _0x315e28(0x1fe),
            'YMQjn': function (_0x2da2ce, _0x503baf) {
                return _0x2da2ce !== _0x503baf;
            },
            'JMgar': _0x315e28(0x201),
            'PPapk': _0x315e28(0x1a8),
            'oBlqo': _0x315e28(0x1db),
            'PKWnT': _0x315e28(0x1b1),
            'xUrvW': _0x315e28(0x1e1),
            'PPQpy': function (_0x3b30ab, _0x2e8371) {
                return _0x3b30ab(_0x2e8371);
            },
            'HdlmQ': _0x315e28(0x191),
            'jOVmg': _0x315e28(0x1a2),
            'gNMhS': 'Powered\x20by\x20ChatUnity',
            'quDbF': _0x315e28(0x18f),
            'ykLlK': _0x315e28(0x19b)
        }, _0x40d938 = [
            _0x2e02e1[_0x315e28(0x1ad)],
            _0x2e02e1[_0x315e28(0x1e2)],
            _0x315e28(0x1c7),
            _0x2e02e1[_0x315e28(0x1ae)]
        ];
    for (const _0x26b801 of _0x40d938) {
        if (_0x2e02e1[_0x315e28(0x1ba)](_0x2e02e1['TIPdJ'], _0x315e28(0x1b7)))
            for (let _0x104df9 = _0x563f49[_0x315e28(0x1c0)] - (0x1a0b + -0x1 * 0x47f + -0x158b * 0x1); _0x2e02e1[_0x315e28(0x199)](_0x104df9, 0x3d * -0x89 + -0x1bfd + 0x3ca2); _0x104df9--) {
                const _0x199619 = _0x2b59a7[_0x315e28(0x210)](_0x2e02e1[_0x315e28(0x1ff)](_0x89e918['random'](), _0x2e02e1[_0x315e28(0x1f0)](_0x104df9, -0xe2 * -0x1b + -0x1 * -0xe99 + -0x266e)));
                [_0x382ea7[_0x104df9], _0x94ec13[_0x199619]] = [
                    _0x486e96[_0x199619],
                    _0x2f4a52[_0x104df9]
                ];
            }
        else {
            if (!_0x2e02e1['pGVEf'](existsSync, _0x26b801))
                return _0x10a941[_0x315e28(0x20c)](_0x862d6c[_0x315e28(0x1cf)], _0x315e28(0x212), _0x862d6c);
        }
    }
    const _0x48c7bf = _0x165293 || _0x862d6c[_0x315e28(0x211)]?.[_0x315e28(0x19e)];
    if (!_0x48c7bf)
        return _0x10a941[_0x315e28(0x20c)](_0x862d6c['chat'], _0x315e28(0x1f5) + _0x2e02e1[_0x315e28(0x1f0)](_0x357a8d, _0x1d3431) + _0x315e28(0x1ea), _0x862d6c);
    const _0x164064 = _0x315e28(0x196) + _0x48c7bf + _0x315e28(0x1f1);
    try {
        const _0x4cb84d = await _0x515abc['post'](_0x315e28(0x218), {
                'content': _0x164064,
                'user': _0x862d6c['pushName'] || _0x2e02e1[_0x315e28(0x1ab)],
                'prompt': _0x315e28(0x1df),
                'webSearchMode': ![]
            }), _0x13610a = _0x4cb84d[_0x315e28(0x20b)]?.['result']?.['toLowerCase']();
        if (_0x13610a['includes'](_0x2e02e1[_0x315e28(0x1d6)]))
            return _0x2e02e1['YMQjn'](_0x2e02e1['JMgar'], _0x2e02e1[_0x315e28(0x1a9)]) ? _0xa1408b[_0x315e28(0x20c)](_0x554447[_0x315e28(0x1cf)], _0x2e02e1[_0x315e28(0x1ca)], _0x218ca9) : _0x10a941[_0x315e28(0x20c)](_0x862d6c[_0x315e28(0x1cf)], _0x2e02e1['PPapk'], _0x862d6c);
    } catch (_0x1de30b) {
        if (_0x2e02e1['oBlqo'] === _0x2e02e1[_0x315e28(0x219)]) {
            if (!_0x431465(_0x2084b6))
                return _0x51ab6c['reply'](_0x3ac910['chat'], _0x2e02e1[_0x315e28(0x1ca)], _0xc2e278);
        } else {
            console[_0x315e28(0x208)](_0x315e28(0x1f6));
            if (paroleproibite['some'](_0x8a5177 => _0x48c7bf[_0x315e28(0x1b2)]()[_0x315e28(0x1af)](_0x8a5177)))
                return _0x10a941[_0x315e28(0x20c)](_0x862d6c[_0x315e28(0x1cf)], _0x315e28(0x214), _0x862d6c);
        }
    }
    const _0x402283 = Math[_0x315e28(0x210)](_0x2e02e1[_0x315e28(0x1ff)](Math['random'](), 0x295 + 0x9d * -0x35 + 0x1df6)), _0x206679 = _0x48c7bf + '\x20' + _0x402283, _0x140816 = await googleImage(_0x206679);
    if (!_0x140816 || _0x140816[_0x315e28(0x1c0)] === 0x7c2 + 0x2261 + -0x2a23)
        return _0x10a941[_0x315e28(0x20c)](_0x862d6c[_0x315e28(0x1cf)], _0x2e02e1['xUrvW'], _0x862d6c);
    _0x2e02e1[_0x315e28(0x1b6)](shuffle, _0x140816);
    const _0x1a4cf6 = _0x140816[_0x315e28(0x213)](-0x1 * 0x235 + 0x198f + -0x175a, -0x69 * 0x3e + -0x10 * -0x23e + 0x11 * -0x9d), _0x392dab = _0x1a4cf6['map']((_0x3fab38, _0x133346) => ({
            'image': { 'url': _0x3fab38 },
            'title': _0x315e28(0x1f9) + (_0x133346 + (0x5 * -0x127 + 0x17d * 0xe + -0x3 * 0x506)),
            'body': _0x315e28(0x1a3) + _0x48c7bf,
            'footer': _0x315e28(0x205),
            'buttons': [{
                    'name': _0x315e28(0x1fd),
                    'buttonParamsJson': JSON[_0x315e28(0x1d7)]({
                        'display_text': _0x315e28(0x1d4),
                        'url': _0x3fab38
                    })
                }]
        }));
    await _0x10a941[_0x315e28(0x1b4)](_0x862d6c[_0x315e28(0x1cf)], {
        'text': '🔍\x20Risultati\x20per:\x20' + _0x48c7bf,
        'title': _0x2e02e1[_0x315e28(0x1c6)],
        'subtitle': _0x2e02e1['jOVmg'],
        'footer': _0x2e02e1[_0x315e28(0x1fc)],
        'cards': _0x392dab
    }, { 'quoted': _0x862d6c }), await _0x10a941[_0x315e28(0x1b4)](_0x862d6c[_0x315e28(0x1cf)], {
        'text': _0x2e02e1[_0x315e28(0x1ce)],
        'footer': _0x2e02e1[_0x315e28(0x1fc)],
        'buttons': [{
                'buttonId': _0x357a8d + _0x315e28(0x1ef) + _0x48c7bf,
                'buttonText': { 'displayText': _0x2e02e1[_0x315e28(0x1e9)] },
                'type': 0x1
            }],
        'headerType': 0x1
    }, { 'quoted': _0x862d6c });
};
function _0x5061() {
    const _0x465c9a = [
        '2384UYLwEX',
        'OBZdd',
        'length',
        'pene',
        'TRDzz',
        'hitler',
        'snuff',
        '42055RpzSNY',
        'HdlmQ',
        './bal.png',
        'nudità',
        'culo',
        'GVNaE',
        'corpo\x20morto',
        'pedofilia',
        'cadavere',
        'quDbF',
        'chat',
        './plugins/OWNER_file.js',
        'xxx',
        '716rQKieD',
        'cam\x20girl',
        'Apri\x20immagine',
        'hot\x20boy',
        'QdWeZ',
        'stringify',
        'arma',
        '20IvVFbc',
        '358767QZJRHD',
        'WaJdn',
        'omofobia',
        'PUxiS',
        'masturbazione',
        'Rispondi\x20con\x20una\x20singola\x20parola.',
        '11WSCeaF',
        'Nessuna\x20immagine\x20trovata\x20😢',
        'rbypt',
        'YjeXt',
        'porno',
        'cercaimmagine',
        'sangue',
        '2164743wZsyZZ',
        'sex',
        'ykLlK',
        '\x20<parola\x20chiave>',
        'stupefacenti',
        'sesso',
        'fake\x20nudes',
        'utente',
        'cercaimmagine\x20',
        'hNtTa',
        '\x22\x0a\x0aSe\x20contiene\x20contenuti\x20sessuali,\x20violenti,\x20razzisti,\x20illegali,\x20deepfake,\x20o\x20simili,\x20rispondi\x20solo\x20con\x20\x22vietato\x22,\x20altrimenti\x20rispondi\x20\x22ok\x22.\x0a',
        'morire',
        'qWffF',
        'tette',
        '>\x20ⓘ\x20Uso\x20del\x20comando:\x0a>\x20',
        'Filtro\x20GPT\x20fallito,\x20fallback\x20su\x20lista\x20manuale.',
        'antisemitismo',
        'gore',
        'Immagine\x20#',
        'bdsm',
        'suicidarsi',
        'gNMhS',
        'cta_url',
        'vietato',
        'dQiQO',
        'deepfake',
        'BYnXg',
        'nudo',
        'hardcore',
        'WuRVo',
        'Powered\x20by\x20ChatUnity',
        'vagina',
        'WmOZy',
        'log',
        'fellatio',
        'mutilazione',
        'data',
        'reply',
        'nuda',
        'razzismo',
        '12cTtpvn',
        'floor',
        'quoted',
        'Questo\x20comando\x20è\x20disponibile\x20solo\x20con\x20la\x20base\x20di\x20ChatUnity.',
        'slice',
        '⚠\x20Questo\x20contenuto\x20non\x20è\x20permesso.',
        'sexy',
        'eroina',
        'stupro',
        'https://luminai.my.id',
        'PKWnT',
        '🔄\x20Vuoi\x20cercare\x20altre\x20immagini\x20con\x20lo\x20stesso\x20termine?',
        'terrorismo',
        'Risultati\x20immagini',
        'impiccarsi',
        'suicidio',
        'traffico\x20di\x20organi',
        './CODE_OF_CONDUCT.md',
        '\x0aControlla\x20se\x20nel\x20seguente\x20testo\x20è\x20presente\x20un\x20termine\x20inappropriato\x20o\x20ostile,\x20in\x20qualsiasi\x20lingua:\x0a\x0a\x22',
        'fetish',
        'sensuale',
        'KTATl',
        'tagliarsi',
        'Cerca\x20di\x20nuovo',
        '681jyFSKg',
        'droga',
        'text',
        'webcam\x20sex',
        '1409336jXnUUP',
        'random',
        'Ecco\x20le\x20immagini\x20trovate\x20su\x20Google',
        'Risultato\x20per:\x20',
        'violentare',
        'autolesionismo',
        'GAZuV',
        'anale',
        '⚠\x20Contenuto\x20non\x20permesso.',
        'JMgar',
        'command',
        'tPLdF',
        'hot\x20girl',
        'jbiPA',
        'njTbd',
        'includes',
        'seni',
        'MRujA',
        'toLowerCase',
        'decapitazione',
        'sendMessage',
        'islamofobia',
        'PPQpy',
        'jtKby',
        'necrofili',
        'omicidio',
        'dZVkb',
        '573xSWlUY',
        'tortura',
        '42060fXNOpy'
    ];
    _0x5061 = function () {
        return _0x465c9a;
    };
    return _0x5061();
}
handler[_0x249066(0x1aa)] = [_0x249066(0x1e5)];
export default handler;