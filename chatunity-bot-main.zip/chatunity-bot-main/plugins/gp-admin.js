function _0x1b88(_0x5a807a, _0x34ba73) {
    const _0x46b59d = _0x31e8();
    return _0x1b88 = function (_0x22e0da, _0x5781ce) {
        _0x22e0da = _0x22e0da - (-0x5 * 0x373 + 0x1 * 0x16eb + 0x1 * -0x3dd);
        let _0x35a252 = _0x46b59d[_0x22e0da];
        return _0x35a252;
    }, _0x1b88(_0x5a807a, _0x34ba73);
}
function _0x31e8() {
    const _0x206d97 = [
        '1jVvpIk',
        '300414Mxjuip',
        '47995RyvEDk',
        'buffer',
        'krqDh',
        '244uKOoAp',
        'messageStubType',
        'sender',
        '466326WEMCqm',
        'vsvUV',
        '𝐌𝐞𝐬𝐬𝐚𝐠𝐠𝐢𝐨\x20𝐝𝐢\x20𝐩𝐫𝐨𝐦𝐨𝐳𝐢𝐨𝐧𝐞\x20👑',
        'jcOTi',
        'kiuPW',
        '\x20𝐡𝐚\x20𝐝𝐚𝐭𝐨\x20𝐚𝐦𝐦𝐢𝐧𝐢𝐬𝐭𝐫𝐚𝐭𝐨𝐫𝐞\x20𝐚\x20@',
        '84BZuFGP',
        'chat',
        'LfbLE',
        'profilePictureUrl',
        '286126BBHBnN',
        'FxcSt',
        '402496mXcxaM',
        '19602QjNyDC',
        'split',
        'https://telegra.ph/file/17e7701f8b0a63806e312.png',
        '2528865VSzelI',
        'image',
        '2190TaNZEk',
        'all',
        'UxWgu',
        'messageStubParameters',
        'sendMessage'
    ];
    _0x31e8 = function () {
        return _0x206d97;
    };
    return _0x31e8();
}
const _0x41cb79 = _0x1b88;
(function (_0x48e7aa, _0x4f9446) {
    const _0x255970 = _0x1b88, _0x515310 = _0x48e7aa();
    while (!![]) {
        try {
            const _0x93538 = parseInt(_0x255970(0x1d6)) / (0x7d * 0x22 + -0x1589 + 0x4f0) * (-parseInt(_0x255970(0x1e8)) / (0x1cdb + -0xbfc + -0x3 * 0x59f)) + -parseInt(_0x255970(0x1de)) / (-0x25c7 + -0x27 * -0xed + -0x1 * -0x1af) + parseInt(_0x255970(0x1db)) / (0xd4d + 0x1 * 0x8df + -0x1628) * (parseInt(_0x255970(0x1d8)) / (-0x24c1 * 0x1 + 0x2 * -0x608 + 0x30d6)) + -parseInt(_0x255970(0x1d7)) / (0x1 * 0x206f + 0x207b + -0x40e4) + -parseInt(_0x255970(0x1e4)) / (0x10a5 * 0x2 + 0x1951 * 0x1 + -0x3a94) * (parseInt(_0x255970(0x1ea)) / (0x64d * -0x3 + 0xf65 + 0x6 * 0x97)) + parseInt(_0x255970(0x1cf)) / (0x22c * 0x8 + 0x1 * -0x1bf7 + -0x5 * -0x220) + -parseInt(_0x255970(0x1d1)) / (-0x529 * -0x5 + -0x1e41 + 0x47e) * (-parseInt(_0x255970(0x1eb)) / (0x25bd * -0x1 + 0x1ecc + 0x6fc));
            if (_0x93538 === _0x4f9446)
                break;
            else
                _0x515310['push'](_0x515310['shift']());
        } catch (_0x479914) {
            _0x515310['push'](_0x515310['shift']());
        }
    }
}(_0x31e8, 0x1 * -0x255a + -0x25 * -0x3a36 + -0x39f24));
const handler = _0x507190 => _0x507190;
handler[_0x41cb79(0x1d2)] = async function (_0x160d58) {
    const _0x49f396 = _0x41cb79, _0x130c18 = {
            'UxWgu': _0x49f396(0x1d0),
            'vsvUV': '120363259442839354@newsletter',
            'jcOTi': _0x49f396(0x1e0),
            'krqDh': function (_0x2bb076, _0x445a39) {
                return _0x2bb076(_0x445a39);
            },
            'kiuPW': _0x49f396(0x1ed),
            'FxcSt': '𝐌𝐞𝐬𝐬𝐚𝐠𝐠𝐢𝐨\x20𝐝𝐢\x20𝐫𝐞𝐭𝐫𝐨𝐜𝐞𝐬𝐬𝐢𝐨𝐧𝐞\x20🙇🏻‍♂️',
            'LfbLE': function (_0x36a462, _0x34e7e7) {
                return _0x36a462(_0x34e7e7);
            }
        };
    if (_0x160d58['messageStubType'] == -0x308 + 0x17a * 0xf + -0x5 * 0x3cd) {
        let _0x53e3b7;
        try {
            _0x53e3b7 = await conn[_0x49f396(0x1e7)](_0x160d58[_0x49f396(0x1d4)][0x3e * 0x74 + 0x4 * 0x712 + -0x3860], _0x130c18[_0x49f396(0x1d3)]);
        } catch (_0x27ab16) {
            _0x53e3b7 = null;
        }
        conn[_0x49f396(0x1d5)](_0x160d58[_0x49f396(0x1e5)], {
            'text': '@' + _0x160d58['sender']['split']('@')[0x2c2 * -0x1 + 0x25 * -0x92 + -0xbee * -0x2] + _0x49f396(0x1e3) + _0x160d58[_0x49f396(0x1d4)][0x1 * -0x5d9 + -0x2523 + -0x624 * -0x7][_0x49f396(0x1ec)]('@')[-0x2332 + -0xd * 0x233 + -0x3fc9 * -0x1],
            'contextInfo': {
                'mentionedJid': [
                    _0x160d58['sender'],
                    _0x160d58[_0x49f396(0x1d4)][0x138b + -0xbfe * -0x2 + -0x2b87]
                ],
                'forwardingScore': 0x63,
                'isForwarded': !![],
                'forwardedNewsletterMessageInfo': {
                    'newsletterJid': _0x130c18[_0x49f396(0x1df)],
                    'serverMessageId': '',
                    'newsletterName': '' + nomebot
                },
                'externalAdReply': {
                    'title': _0x130c18[_0x49f396(0x1e1)],
                    'thumbnail': _0x53e3b7 ? await (await _0x130c18[_0x49f396(0x1da)](fetch, _0x53e3b7))[_0x49f396(0x1d9)]() : await (await _0x130c18[_0x49f396(0x1da)](fetch, _0x130c18['kiuPW']))['buffer']()
                }
            }
        }, { 'quoted': null });
    }
    if (_0x160d58[_0x49f396(0x1dc)] == 0x1e * -0x49 + 0x7b + 0x3 * 0x2bb) {
        let _0x20cd89;
        try {
            _0x20cd89 = await conn['profilePictureUrl'](_0x160d58[_0x49f396(0x1d4)][-0x3 * 0xac5 + 0x3 * -0x355 + -0x2d2 * -0xf], _0x130c18['UxWgu']);
        } catch (_0x3ab5bb) {
            _0x20cd89 = null;
        }
        conn[_0x49f396(0x1d5)](_0x160d58[_0x49f396(0x1e5)], {
            'text': '@' + _0x160d58[_0x49f396(0x1dd)][_0x49f396(0x1ec)]('@')[-0x1 * 0x2d8 + -0xa1 * 0x1e + 0x15b6] + '\x20𝐡𝐚\x20𝐭𝐨𝐥𝐭𝐨\x20𝐚𝐦𝐦𝐢𝐧𝐢𝐬𝐭𝐫𝐚𝐭𝐨𝐫𝐞\x20𝐚\x20@' + _0x160d58[_0x49f396(0x1d4)][0x1 * 0x41d + -0x907 + -0x11 * -0x4a]['split']('@')[0x2f5 * -0x3 + -0xe9c + 0x1 * 0x177b],
            'contextInfo': {
                'mentionedJid': [
                    _0x160d58['sender'],
                    _0x160d58['messageStubParameters'][0xa9 * -0x10 + 0x24d1 + -0x1a41]
                ],
                'forwardingScore': 0x63,
                'isForwarded': !![],
                'forwardedNewsletterMessageInfo': {
                    'newsletterJid': '120363259442839354@newsletter',
                    'serverMessageId': '',
                    'newsletterName': '' + nomebot
                },
                'externalAdReply': {
                    'title': _0x130c18[_0x49f396(0x1e9)],
                    'thumbnail': _0x20cd89 ? await (await fetch(_0x20cd89))['buffer']() : await (await _0x130c18[_0x49f396(0x1e6)](fetch, _0x130c18[_0x49f396(0x1e2)]))[_0x49f396(0x1d9)]()
                }
            }
        }, { 'quoted': null });
    }
};
export default handler;