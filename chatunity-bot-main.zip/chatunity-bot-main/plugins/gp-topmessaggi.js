const _0xee2b6f = _0x2f1c;
(function (_0x4283c7, _0x10a3da) {
    const _0xad341a = _0x2f1c, _0x993911 = _0x4283c7();
    while (!![]) {
        try {
            const _0x1a73d7 = -parseInt(_0xad341a(0x89)) / (-0x225d + -0xa3a * 0x1 + 0x2c98) * (-parseInt(_0xad341a(0xe4)) / (-0x38a + -0x26a9 + 0x2a35)) + parseInt(_0xad341a(0xab)) / (-0x4d7 * -0x3 + 0x25f2 + -0x3474) * (parseInt(_0xad341a(0xec)) / (0x19b6 + -0x378 + -0x163a)) + parseInt(_0xad341a(0xf9)) / (0x2674 + -0xf83 + -0x12 * 0x146) + -parseInt(_0xad341a(0xcc)) / (0xeff * -0x2 + -0x1 * -0x1442 + 0x9c2) + parseInt(_0xad341a(0xc5)) / (-0x385 + -0x1 * 0x1d99 + 0x2125) * (parseInt(_0xad341a(0xbf)) / (0x21a2 + -0x9d9 + 0x17c1 * -0x1)) + parseInt(_0xad341a(0xca)) / (0x1380 + -0x1bb4 + 0x83d) + parseInt(_0xad341a(0x97)) / (0xa24 + -0x1c47 + 0x21 * 0x8d) * (-parseInt(_0xad341a(0xb0)) / (-0x9 * -0x3c1 + 0x19bb + 0x13d3 * -0x3));
            if (_0x1a73d7 === _0x10a3da)
                break;
            else
                _0x993911['push'](_0x993911['shift']());
        } catch (_0x410c61) {
            _0x993911['push'](_0x993911['shift']());
        }
    }
}(_0x2fab, -0xfb92a + -0xcb485 + 0x2540c2));
import _0x49a71b from 'node-fetch';
import _0x1cc81c from 'fs';
function sort(_0x3b452a, _0x128e4f = !![]) {
    return _0x3b452a ? (_0x1550f6, _0x27d458) => _0x128e4f ? _0x1550f6[_0x3b452a] - _0x27d458[_0x3b452a] : _0x27d458[_0x3b452a] - _0x1550f6[_0x3b452a] : (_0x2e137b, _0x1bad51) => _0x128e4f ? _0x2e137b - _0x1bad51 : _0x1bad51 - _0x2e137b;
}
function _0x2f1c(_0x724a7b, _0xe1b3a8) {
    const _0x3d508b = _0x2fab();
    return _0x2f1c = function (_0x214deb, _0x42a53e) {
        _0x214deb = _0x214deb - (0x25f1 + -0x12e5 + -0x65 * 0x2f);
        let _0x355057 = _0x3d508b[_0x214deb];
        return _0x355057;
    }, _0x2f1c(_0x724a7b, _0xe1b3a8);
}
function getMedaglia(_0x2523cc) {
    const _0x5af5ea = _0x2f1c, _0xf07bbc = {
            'eFltV': function (_0xaa10d8, _0x15aa2a) {
                return _0xaa10d8 === _0x15aa2a;
            },
            'xZcsu': function (_0x35cfee, _0x49e126) {
                return _0x35cfee === _0x49e126;
            },
            'cLcqf': function (_0x44ff10, _0x789896) {
                return _0x44ff10 === _0x789896;
            }
        };
    if (_0xf07bbc[_0x5af5ea(0xc0)](_0x2523cc, -0x259c + 0x1 * 0xedd + -0x16c0 * -0x1))
        return '🥇';
    if (_0xf07bbc[_0x5af5ea(0xef)](_0x2523cc, -0x1 * 0x2519 + -0xf6d * -0x2 + 0x641))
        return '🥈';
    if (_0xf07bbc[_0x5af5ea(0xb7)](_0x2523cc, 0x2409 + -0x1ca6 * -0x1 + -0x40ac))
        return '🥉';
    return '🏅';
}
const handler = async (_0x5607fa, {
    conn: _0x4bf8c9,
    args: _0x274841,
    participants: _0x4370e9
}) => {
    const _0x5060fb = _0x2f1c, _0x328f7b = {
            'gGhwG': _0x5060fb(0xb3),
            'rkdzG': function (_0x2e8576, _0x2f4b74) {
                return _0x2e8576 !== _0x2f4b74;
            },
            'CKPLs': _0x5060fb(0xa6),
            'mDKnS': function (_0x13cd1a, _0x3fb4de) {
                return _0x13cd1a === _0x3fb4de;
            },
            'jPRaK': _0x5060fb(0x83),
            'mnDPG': _0x5060fb(0xe0),
            'qJfMm': function (_0x53b2ef, _0x546388) {
                return _0x53b2ef(_0x546388);
            },
            'cZQJF': function (_0x46d953, _0x3ddbd5) {
                return _0x46d953 + _0x3ddbd5;
            },
            'jmWXU': _0x5060fb(0xa5),
            'emjJm': function (_0xaa4c7f, _0x33d13b) {
                return _0xaa4c7f === _0x33d13b;
            },
            'giUbs': _0x5060fb(0xbe),
            'wwGNC': 'image',
            'ORHQN': 'Membro\x20🤍',
            'uEvmw': function (_0x577d83, _0x40a959) {
                return _0x577d83 !== _0x40a959;
            },
            'LMOji': 'OrKaV',
            'RZcSA': _0x5060fb(0x95),
            'WyBnv': _0x5060fb(0xf7),
            'qmWRh': function (_0x3d1628, _0x388b38) {
                return _0x3d1628 === _0x388b38;
            },
            'LkDWK': _0x5060fb(0xdb),
            'koYBa': _0x5060fb(0xa8),
            'frzUV': _0x5060fb(0xa1),
            'TcWdk': 'Avanzato\x20I\x20🫡',
            'tnKqv': _0x5060fb(0xc1),
            'rScfz': _0x5060fb(0x81),
            'JjqRH': _0x5060fb(0x9b),
            'jCJCq': 'Pro\x20II\x20😤',
            'zefVs': _0x5060fb(0xd9),
            'ONvtF': _0x5060fb(0xee),
            'ZknEr': _0x5060fb(0xfa),
            'QgZkS': _0x5060fb(0xcd),
            'RCqYZ': _0x5060fb(0xd2),
            'IByDy': _0x5060fb(0xda),
            'KRskb': _0x5060fb(0x90),
            'gFPZb': 'Dominatore\x20II\x20🥶',
            'NdREh': 'Stellare\x20I\x20💫',
            'YWOWb': _0x5060fb(0xbb),
            'pDyAH': _0x5060fb(0x10c),
            'ZyctS': _0x5060fb(0x105),
            'XhCJr': 'Titano\x20I\x20😈',
            'qJSYQ': _0x5060fb(0xc4),
            'jmgSV': _0x5060fb(0x10d),
            'alZww': _0x5060fb(0xf5),
            'uZsDK': function (_0x182f12, _0x18cb2a) {
                return _0x182f12 >= _0x18cb2a;
            },
            'LSboT': _0x5060fb(0xad),
            'xwnhA': function (_0x53b90c, _0x3cb828) {
                return _0x53b90c === _0x3cb828;
            },
            'msEPV': _0x5060fb(0x85),
            'CnDiQ': _0x5060fb(0xaa),
            'qfyen': function (_0x286f86, _0x549496) {
                return _0x286f86 + _0x549496;
            },
            'QWMYD': function (_0x2e6ec2, _0x342250) {
                return _0x2e6ec2 + _0x342250;
            },
            'iIGpP': _0x5060fb(0x87),
            'xJUNz': _0x5060fb(0x8f),
            'qXUrU': _0x5060fb(0xc3),
            'wiqja': function (_0x420996, _0x443a2e) {
                return _0x420996(_0x443a2e);
            },
            'qdHRD': function (_0x46a0ab, _0x105651) {
                return _0x46a0ab <= _0x105651;
            },
            'ydXWb': function (_0x50419c, _0x1ca402) {
                return _0x50419c % _0x1ca402;
            },
            'chNGs': function (_0x18918c, _0x587fad) {
                return _0x18918c !== _0x587fad;
            },
            'AkuWl': _0x5060fb(0xc2),
            'gELVT': function (_0x894d25, _0x3a4ef6, _0x440d18) {
                return _0x894d25(_0x3a4ef6, _0x440d18);
            },
            'lvMKX': _0x5060fb(0xe6)
        }, _0x3ccbd1 = [
            _0x328f7b[_0x5060fb(0x86)],
            _0x5060fb(0xb8),
            _0x328f7b[_0x5060fb(0xa2)],
            _0x328f7b[_0x5060fb(0xa7)]
        ], _0x23bafd = _0x3ccbd1[_0x5060fb(0xc7)](_0x3c5135 => !_0x1cc81c[_0x5060fb(0xd4)](_0x3c5135));
    if (_0x23bafd)
        return await _0x4bf8c9[_0x5060fb(0xd0)](_0x5607fa['chat'], { 'text': _0x5060fb(0xfc) }, { 'quoted': _0x5607fa });
    if (!_0x5607fa['isGroup'])
        return await _0x5607fa[_0x5060fb(0xea)](_0x5060fb(0x92));
    let _0x598bb6 = 0x1f70 + 0x1 * 0xbb1 + -0x2b17;
    if (_0x274841[0x1e1 * -0x13 + -0xba8 + 0x2f5b]) {
        let _0x5d8632 = _0x328f7b[_0x5060fb(0x10a)](parseInt, _0x274841[0xc3f + -0x1e02 + -0x11c3 * -0x1]);
        if (!_0x328f7b[_0x5060fb(0x10a)](isNaN, _0x5d8632) && _0x328f7b[_0x5060fb(0x98)](_0x5d8632, -0x27 * -0x52 + 0x2419 + -0x308d * 0x1) && _0x328f7b[_0x5060fb(0x9f)](_0x5d8632, 0x3c * 0x1b + 0x30 * -0x51 + 0x40 * 0x25) && _0x328f7b[_0x5060fb(0x91)](_0x328f7b[_0x5060fb(0x102)](_0x5d8632, -0x1348 * 0x1 + 0x61 * 0x14 + 0xbbe), -0x1 * 0x17f + -0x1 * -0xd33 + -0xbb4)) {
            if (_0x328f7b[_0x5060fb(0xdd)](_0x328f7b[_0x5060fb(0xb6)], _0x5060fb(0x109)))
                _0x598bb6 = _0x5d8632;
            else {
                let _0x1654ad = _0x49edee['db'][_0x5060fb(0xba)][_0x5060fb(0xd3)][_0x574c0a['id']] || {};
                return {
                    'jid': _0xe025ea['id'],
                    'messaggi': _0x1654ad['messaggi'] || -0x10 * 0x202 + -0x142e * 0x1 + 0x1a27 * 0x2,
                    'userData': _0x1654ad
                };
            }
        }
    }
    let _0xe256b8 = _0x4370e9[_0x5060fb(0xa3)](_0x54abf8 => _0x54abf8['id'] !== _0x4bf8c9[_0x5060fb(0xe2)][_0x5060fb(0xd7)])['map'](_0x1f3030 => {
            const _0x324fc4 = _0x5060fb;
            if (_0x328f7b[_0x324fc4(0x8e)](_0x328f7b[_0x324fc4(0x9a)], _0x324fc4(0xa6)))
                _0x10e91a = _0x328f7b[_0x324fc4(0xfd)];
            else {
                let _0x3cb547 = global['db'][_0x324fc4(0xba)][_0x324fc4(0xd3)][_0x1f3030['id']] || {};
                return {
                    'jid': _0x1f3030['id'],
                    'messaggi': _0x3cb547[_0x324fc4(0x10b)] || -0x1 * -0x1dd7 + 0x1882 * 0x1 + -0x3659,
                    'userData': _0x3cb547
                };
            }
        }), _0x45555d = _0xe256b8[_0x5060fb(0x8a)](_0x328f7b[_0x5060fb(0xed)](sort, _0x5060fb(0x10b), ![])), _0x15941e = _0x45555d[_0x5060fb(0x8d)](0x1ae4 + 0x1319 * -0x1 + -0x7cb, _0x598bb6), _0xe51812 = await Promise['all'](_0x15941e[_0x5060fb(0x88)](async ({
            jid: _0x5ab9fc,
            messaggi: _0x2a15b5,
            userData: _0x2fcd32
        }, _0x4cef9d) => {
            const _0x143c4c = _0x5060fb, _0x952ec6 = {
                    'BIzSE': function (_0x579669, _0x4a404d) {
                        return _0x579669 === _0x4a404d;
                    },
                    'uERbc': function (_0x1c75fc, _0x5a639e) {
                        const _0x5116ba = _0x2f1c;
                        return _0x328f7b[_0x5116ba(0x108)](_0x1c75fc, _0x5a639e);
                    }
                };
            if (_0x328f7b['jPRaK'] !== _0x328f7b[_0x143c4c(0x84)]) {
                let _0x3ff752 = _0x328f7b[_0x143c4c(0xdc)](getMedaglia, _0x328f7b[_0x143c4c(0xb4)](_0x4cef9d, -0x1ef + 0xa16 * 0x3 + -0x1c52)), _0x3d2851;
                try {
                    if (_0x143c4c(0x82) !== _0x328f7b[_0x143c4c(0xf8)])
                        _0x3d2851 = await _0x4bf8c9[_0x143c4c(0xbc)](_0x5ab9fc);
                    else {
                        if (_0x952ec6[_0x143c4c(0xf3)](_0xaa1ddb, 0x1f16 + 0xf1 * -0x19 + -0x78c))
                            return '🥇';
                        if (_0x952ec6[_0x143c4c(0xac)](_0x5de325, -0x1 * -0x21e1 + -0x55b + -0x1c84))
                            return '🥈';
                        if (_0x952ec6[_0x143c4c(0xac)](_0x3db413, 0x31d + -0x25af + -0xe3 * -0x27))
                            return '🥉';
                        return '🏅';
                    }
                } catch {
                    _0x328f7b[_0x143c4c(0xf6)](_0x143c4c(0xbe), _0x328f7b[_0x143c4c(0xd8)]) ? _0x3d2851 = _0x5ab9fc[_0x143c4c(0xcf)]('@')[0xaa0 + -0x8eb + -0x1b5] : _0x45db74 = _0x2fce24;
                }
                let _0x1facd6;
                try {
                    _0x1facd6 = await _0x4bf8c9[_0x143c4c(0xe7)](_0x5ab9fc, _0x328f7b[_0x143c4c(0x10e)]);
                } catch {
                    _0x1facd6 = _0x328f7b[_0x143c4c(0xfd)];
                }
                let _0x13db2c = _0x328f7b[_0x143c4c(0xeb)];
                try {
                    if (_0x328f7b[_0x143c4c(0x104)](_0x328f7b[_0x143c4c(0xf2)], _0x328f7b[_0x143c4c(0xf2)]))
                        return (_0x40f418, _0x2f1351) => _0x3dd537 ? _0x40f418[_0x2d120e] - _0x2f1351[_0x41f5a5] : _0x2f1351[_0x208a80] - _0x40f418[_0x548985];
                    else {
                        let _0x241609 = await _0x4bf8c9[_0x143c4c(0xa0)](_0x5607fa[_0x143c4c(0xd5)]), _0x4f4273 = _0x241609[_0x143c4c(0xb2)][_0x143c4c(0xc7)](_0x49f144 => _0x49f144['id'] === _0x5ab9fc);
                        if (_0x4f4273) {
                            if (_0x4f4273[_0x143c4c(0xf7)] === _0x328f7b['RZcSA'] || _0x328f7b[_0x143c4c(0x108)](_0x4f4273[_0x143c4c(0xf7)], _0x328f7b['WyBnv']))
                                _0x13db2c = _0x143c4c(0x96);
                            if (_0x328f7b[_0x143c4c(0xbd)](_0x241609['owner'], _0x5ab9fc))
                                _0x13db2c = _0x143c4c(0xc8);
                        }
                    }
                } catch {
                }
                const _0x363cf3 = [
                        _0x328f7b[_0x143c4c(0xde)],
                        _0x328f7b[_0x143c4c(0xe3)],
                        _0x328f7b[_0x143c4c(0xe8)],
                        _0x143c4c(0xe9),
                        _0x328f7b[_0x143c4c(0x10f)],
                        _0x328f7b[_0x143c4c(0xe5)],
                        _0x328f7b['rScfz'],
                        _0x328f7b['JjqRH'],
                        _0x143c4c(0x8b),
                        _0x328f7b[_0x143c4c(0x9d)],
                        _0x328f7b[_0x143c4c(0xcb)],
                        _0x328f7b[_0x143c4c(0x93)],
                        _0x328f7b['ZknEr'],
                        _0x143c4c(0xf0),
                        _0x143c4c(0xa4),
                        _0x328f7b[_0x143c4c(0x9c)],
                        'Eroe\x20I\x20🎖',
                        'Eroe\x20II\x20🎖',
                        _0x328f7b[_0x143c4c(0x101)],
                        _0x328f7b[_0x143c4c(0x103)],
                        _0x328f7b[_0x143c4c(0xb9)],
                        _0x328f7b['gFPZb'],
                        _0x328f7b['NdREh'],
                        _0x328f7b['YWOWb'],
                        _0x328f7b['pDyAH'],
                        _0x328f7b[_0x143c4c(0x100)],
                        _0x328f7b[_0x143c4c(0xae)],
                        _0x328f7b['qJSYQ'],
                        _0x328f7b[_0x143c4c(0xf4)],
                        _0x328f7b['alZww']
                    ], _0x2d44d5 = Math[_0x143c4c(0xff)](_0x2a15b5 / (0x597 + -0x2321 + 0x2172 * 0x1)), _0x595eea = _0x328f7b[_0x143c4c(0x98)](_0x2d44d5, -0x2 * -0x773 + -0x4f * 0x11 + -0x989 * 0x1) ? _0x328f7b[_0x143c4c(0xd1)] : _0x363cf3[_0x2d44d5] || '-';
                let _0x3b754d = _0x143c4c(0x8c);
                if (_0x328f7b[_0x143c4c(0x91)](_0x2fcd32['genere'], _0x143c4c(0xdf)))
                    _0x3b754d = '🚹';
                else {
                    if (_0x2fcd32[_0x143c4c(0xc6)] === _0x328f7b[_0x143c4c(0x106)])
                        _0x3b754d = '🚺';
                }
                let _0x51ba51 = _0x2fcd32[_0x143c4c(0xfe)] ? '🌐\x20instagram.com/' + _0x2fcd32['instagram'] : _0x328f7b[_0x143c4c(0xb5)], _0x5842b0 = _0x328f7b[_0x143c4c(0xb4)](_0x328f7b[_0x143c4c(0xb4)](_0x328f7b[_0x143c4c(0x107)](_0x3ff752 + '\x20' + _0x3d2851 + '\x0a', _0x143c4c(0xa9) + _0x2a15b5 + '\x0a') + (_0x143c4c(0x110) + _0x13db2c + '\x0a'), _0x143c4c(0xf1) + _0x595eea + '\x0a'), _0x143c4c(0x94) + _0x3b754d + '\x0a') + ('' + _0x51ba51);
                return {
                    'image': { 'url': _0x1facd6 },
                    'title': '#' + _0x328f7b[_0x143c4c(0xaf)](_0x4cef9d, 0x2489 * -0x1 + 0x1 * 0x1953 + 0x3 * 0x3bd),
                    'body': _0x5842b0,
                    'footer': 'Top\x20messaggi\x20' + _0x598bb6 + _0x143c4c(0x99)
                };
            } else
                _0x56a529 = _0x5c55f8['split']('@')[-0x4d5 * -0x1 + 0x1e33 + -0x13 * 0x1d8];
        }));
    await _0x4bf8c9[_0x5060fb(0xd0)](_0x5607fa[_0x5060fb(0xd5)], {
        'title': _0x5060fb(0x9e) + _0x598bb6 + _0x5060fb(0xc9),
        'text': _0x328f7b[_0x5060fb(0xb1)],
        'footer': _0x5060fb(0xce),
        'cards': _0xe51812
    }, { 'quoted': _0x5607fa });
};
function _0x2fab() {
    const _0x51a7dd = [
        '3UowfdY',
        'uERbc',
        'Fuori\x20classe\x20❤‍🔥',
        'XhCJr',
        'QWMYD',
        '199012MvKgsX',
        'lvMKX',
        'participants',
        'https://qu.ax/LoGxD.png',
        'cZQJF',
        'CnDiQ',
        'AkuWl',
        'cLcqf',
        './termini.jpeg',
        'KRskb',
        'data',
        'Stellare\x20II\x20💫',
        'getName',
        'qmWRh',
        'zoXgC',
        '173536RhncLU',
        'eFltV',
        'Avanzato\x20II\x20🫡',
        'vVSgl',
        './plugins/OWNER_file.js',
        'Titano\x20II\x20😈',
        '266jjKeZZ',
        'genere',
        'find',
        'Founder\x20⚜',
        '\x20utenti\x20per\x20messaggi',
        '9475029uudJrg',
        'zefVs',
        '951822BvnEXR',
        'Mitico\x20II\x20🔥',
        'Usa\x20.info\x20@menzione\x20per\x20più\x20informazioni\x20di\x20su\x20ciascun\x20utente',
        'split',
        'sendMessage',
        'LSboT',
        'Campione\x20I\x20🏆',
        'users',
        'existsSync',
        'chat',
        'group',
        'jid',
        'giUbs',
        'Élite\x20I\x20🤩',
        'Campione\x20II\x20🏆',
        'Principiante\x20I\x20😐',
        'qJfMm',
        'chNGs',
        'LkDWK',
        'maschio',
        'ZWqYz',
        'topmessaggi',
        'user',
        'koYBa',
        '12lFqMfB',
        'tnKqv',
        'Guarda\x20chi\x20spacca\x20di\x20più\x20nel\x20gruppo!\x20🏅',
        'profilePictureUrl',
        'frzUV',
        'Recluta\x20II\x20🙂',
        'reply',
        'ORHQN',
        '682228DfadKg',
        'gELVT',
        'Élite\x20II\x20🤩',
        'xZcsu',
        'Master\x20II\x20💪🏼',
        '🏅\x20Livello:\x20',
        'LMOji',
        'BIzSE',
        'jmgSV',
        'Leggenda\x20II\x20⭐',
        'emjJm',
        'admin',
        'jmWXU',
        '650900UKJgYD',
        'Master\x20I\x20💪🏼',
        'command',
        '❗\x20Per\x20usare\x20questo\x20comando\x20usa\x20la\x20base\x20di\x20chatunity',
        'gGhwG',
        'instagram',
        'floor',
        'ZyctS',
        'RCqYZ',
        'ydXWb',
        'IByDy',
        'uEvmw',
        'Cosmico\x20II\x20🔮',
        'msEPV',
        'qfyen',
        'mDKnS',
        'ASXwp',
        'wiqja',
        'messaggi',
        'Cosmico\x20I\x20🔮',
        'Leggenda\x20I\x20⭐',
        'wwGNC',
        'TcWdk',
        '🟣\x20Ruolo:\x20',
        'Bomber\x20I\x20😎',
        'dOXKm',
        'YcgeV',
        'mnDPG',
        'femmina',
        'iIGpP',
        './bal.png',
        'map',
        '160897IIgmGa',
        'sort',
        'Pro\x20I\x20😤',
        'Non\x20impostato',
        'slice',
        'rkdzG',
        './CODE_OF_CONDUCT.md',
        'Dominatore\x20I\x20🥶',
        'xwnhA',
        'Questo\x20comando\x20funziona\x20solo\x20nei\x20gruppi!',
        'ONvtF',
        '🚻\x20Genere:\x20',
        'superadmin',
        'Admin\x20👑',
        '1330foHRPb',
        'uZsDK',
        '\x20utenti',
        'CKPLs',
        'Bomber\x20II\x20😎',
        'QgZkS',
        'jCJCq',
        '🏆\x20Top\x20',
        'qdHRD',
        'groupMetadata',
        'Recluta\x20I\x20🙂',
        'xJUNz',
        'filter',
        'Mitico\x20I\x20🔥',
        'VTeWS',
        'VrhzP',
        'qXUrU',
        'Principiante\x20II\x20😐',
        '📝\x20Messaggi:\x20',
        '🌐\x20Instagram:\x20non\x20impostato'
    ];
    _0x2fab = function () {
        return _0x51a7dd;
    };
    return _0x2fab();
}
handler[_0xee2b6f(0xfb)] = [_0xee2b6f(0xe1)], handler[_0xee2b6f(0xd6)] = !![], handler[_0xee2b6f(0xf7)] = ![];
export default handler;